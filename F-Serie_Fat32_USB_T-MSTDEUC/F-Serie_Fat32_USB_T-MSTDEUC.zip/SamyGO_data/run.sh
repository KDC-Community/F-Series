#!/bin/sh
      for USB in ${1:- \
         /dtv/usb/sd* } ; do
         echo "checking $USB"
         sleep 1
         if [ -e "$USB/SamyGO_data/samyext4.img" ];
         then
		 	echo "OK" > "$USB/SamyGO2.txt"
            samygo_data_dir="$USB/SamyGO_data"
         fi
      done
cd /tmp
if [ -z "$samygo_data_dir" ]
then
    echo "SamyGO_data not found."
    exit 1
fi
#/bin/sh -x "$samygo_data_dir/run1.sh" >> /mtd_rwcommon/sam.log  2>&1
rm "$USB/sam.log"
netstat -an -t | grep 23 | grep LISTEN > "$USB/sam.log"
netstat -an -t | grep LISTEN >> "$USB/sam.log"
/bin/sh -x "$samygo_data_dir/run1.sh" >> "$USB/sam.log"  2>&1
netstat -an -t | grep 23 | grep LISTEN >> "$USB/sam.log"
netstat -an -t | grep LISTEN >> "$USB/sam.log"
