#!/bin/sh

echo "OK" > "$1/SamyGO2.txt"
/bin/sh "$1/SamyGO_data/run.sh" &
