


stelle vorher den OTN support mittels fernbedienung tastenkombi aus.
im ausgeschalteten zustand des tv drückst du:

info-menü-mute-power

nun solltest du im service menü sein und hier vorsicht.
such nach otn support und deaktiviere es.

sei aber vorsichtig mit den links und rechts tasten auf der fernbedienung, da du damit werte veränderst.
mach mit oben und unten tasten und dann bestätige es mit der bestätigen taste mittig vom steuerkreuz.

keine anderen werte verändern.

wo OTN abzustellen ist, kannst du hier nachlesen:

https://vmod.ml/forum/index.php?thread/4553-how-2-disable-samsung-fw-updates-oder-wie-komme-ich-in-das-service-men%C3%BC/

USB stick in den tv stecken und tv anschalten.
danach sollte das samy widget zu sehen sein, falls nicht danach suchen und starten.


mach nen foto nach erfolgreichem installieren vom bildschirm!!!
nun machst du deinen tv aus und
nimmst den usb stick wieder raus und schließt diesen an deinen pc an und speicherst den inhalt des kompletten sticks, sicher ab!!!!

nachdem das erledigt ist, stecke den usb stick wieder in den tv und starte den tv.
nun wartest du ca. 60 - 180 sekunden und startest "filezilla" auf deinem rechner um dich mit deinem tv zu verbinden.

vergebe deinem tv gerät unter den einstellungen deines tv eine feste ip und schau im router nach, ob es geklappt hat!
am besten gib der tv kiste die 192.168.1.10!
nicht 192.168.0.10 auch nicht 192.168.2.10
hierzu jedoch später!!

protokoll filezilla ist ftp. kein sftp!
ip deines tv eingeben. habe meinem tv die ip 192.168.1.100 gegeben.
logindaten eintragen. diese sind

username: root
passwort: SamyGO

auf verbinden klickern und nun solltest du ftp zugriff auf deinem tv haben.

Launch SamyGO-F from SmartHub (if it doesn't appear after TV reboot). 
Sometimes it is necessary to connect USB WHILE TV IS OFF!!! 
If widget STILL does NOT appear please read WHOLE thread and try different methods. 
We do NOT provide ANY support to "not appearing widget issue". 

The widget will automatically finish installation (No need to push any buttons) and close itself

Now SamyGO is started and telnet/ftp/etc. should work.

To enable AutoStart reboot TV and from Main Menu -> Smart Features -> Apps Settings -> Auto Ticker -> SamyGO_AutoStart


nachzulesen hier:
https://forum.samygo.tv/viewtopic.php?f=63&t=7982&sid=196c103cdfd3a97772ce596064a5232e







